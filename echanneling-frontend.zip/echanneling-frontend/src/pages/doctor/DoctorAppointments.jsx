import React, { useEffect, useState } from 'react';
import { ClipboardList } from 'lucide-react';
import api from '../../services/api';
import { Table, StatusBadge, PageHeader, EmptyState, Spinner } from '../../components/UI';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';

export default function DoctorAppointments() {
  const { user } = useAuth();
  const { addToast } = useToast();
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Fetch doctor's appointments — adjust endpoint if backend provides /doctor/{id}/appointments
    api.get(`/doctor/${user.id}/appointments`)
      .then(r => setAppointments(r.data))
      .catch(() => {
        addToast('Appointments endpoint: ensure /doctor/{id}/appointments exists on backend.', 'warning');
        setAppointments([]);
      })
      .finally(() => setLoading(false));
  }, [user]);

  return (
    <div>
      <PageHeader title="My appointments" subtitle="Patients booked for your sessions" />
      <div className="card animate-slide-up">
        {loading ? (
          <div className="flex justify-center py-12"><Spinner size={24} className="text-primary-500" /></div>
        ) : appointments.length === 0 ? (
          <EmptyState icon={ClipboardList} title="No appointments yet" description="Patients will appear here once they book a slot." />
        ) : (
          <Table headers={['Patient', 'Date', 'Start time', 'Type', 'Status']}>
            {appointments.map(a => (
              <tr key={a.id} className="table-row animate-fade-in">
                <td className="px-4 py-3 font-medium text-gray-800 text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-full bg-primary-100 flex items-center justify-center text-primary-700 text-xs font-semibold shrink-0">
                      {a.patient?.fullName?.charAt(0)}
                    </div>
                    {a.patient?.fullName}
                  </div>
                </td>
                <td className="px-4 py-3 text-sm text-gray-600">{a.schedule?.availableDate}</td>
                <td className="px-4 py-3 text-sm text-gray-500">{a.schedule?.startTime}</td>
                <td className="px-4 py-3"><StatusBadge status={a.type} /></td>
                <td className="px-4 py-3"><StatusBadge status={a.status} /></td>
              </tr>
            ))}
          </Table>
        )}
      </div>
    </div>
  );
}
