import React, { useEffect, useState } from 'react';
import { Coins, TrendingUp } from 'lucide-react';
import { paymentAPI } from '../../services/api';
import { PageHeader, Spinner } from '../../components/UI';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';

export default function DoctorEarnings() {
  const { user } = useAuth();
  const { addToast } = useToast();
  const [earnings, setEarnings] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    paymentAPI.getDoctorEarnings(user.id)
      .then(r => setEarnings(r.data))
      .catch(() => addToast('Failed to load earnings.', 'error'))
      .finally(() => setLoading(false));
  }, [user]);

  return (
    <div>
      <PageHeader title="My earnings" subtitle="Revenue from consultations" />
      {loading ? (
        <div className="flex justify-center py-12"><Spinner size={24} className="text-primary-500" /></div>
      ) : (
        <div className="max-w-sm animate-bounce-once">
          <div className="card bg-gradient-to-br from-primary-500 to-primary-700 border-0 text-center py-10">
            <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center mx-auto mb-4">
              <Coins size={28} className="text-white" />
            </div>
            <p className="text-primary-100 text-sm mb-1">Total earnings</p>
            <p className="text-white text-4xl font-bold">
              LKR {(earnings || 0).toLocaleString()}
            </p>
            <div className="flex items-center justify-center gap-2 mt-4">
              <TrendingUp size={14} className="text-primary-200" />
              <p className="text-primary-200 text-xs">From all confirmed appointments</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
