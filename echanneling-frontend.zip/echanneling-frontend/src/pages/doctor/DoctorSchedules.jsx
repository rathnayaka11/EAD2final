import React, { useEffect, useState } from 'react';
import { Plus, Calendar, Clock, Users } from 'lucide-react';
import { doctorAPI } from '../../services/api';
import { PageHeader, EmptyState, Modal, FormField, Spinner } from '../../components/UI';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';

export default function DoctorSchedules() {
  const { user } = useAuth();
  const { addToast } = useToast();
  const [schedules, setSchedules] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ availableDate: '', startTime: '', endTime: '', maxAppointments: '' });

  const fetchSchedules = () => {
    setLoading(true);
    doctorAPI.getSchedules(user.id)
      .then(r => setSchedules(r.data))
      .catch(() => addToast('Failed to load schedules.', 'error'))
      .finally(() => setLoading(false));
  };

  useEffect(() => { if (user?.id) fetchSchedules(); }, [user]);

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await doctorAPI.createSchedule(user.id, {
        availableDate: form.availableDate,
        startTime: form.startTime + ':00',
        endTime: form.endTime + ':00',
        maxAppointments: parseInt(form.maxAppointments),
      });
      addToast('Schedule added successfully!');
      setShowModal(false);
      setForm({ availableDate: '', startTime: '', endTime: '', maxAppointments: '' });
      fetchSchedules();
    } catch {
      addToast('Failed to add schedule.', 'error');
    }
    setSaving(false);
  };

  const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  return (
    <div>
      <PageHeader
        title="My schedules"
        subtitle="Manage your available slots for appointments"
        action={
          <button onClick={() => setShowModal(true)} className="btn-primary">
            <Plus size={16} /> Add schedule
          </button>
        }
      />

      {loading ? (
        <div className="flex justify-center py-12"><Spinner size={24} className="text-primary-500" /></div>
      ) : schedules.length === 0 ? (
        <div className="card">
          <EmptyState icon={Calendar} title="No schedules yet" description="Add your first available slot to start receiving appointments." />
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {schedules.map((s, i) => {
            const d = new Date(s.availableDate + 'T00:00:00');
            return (
              <div key={s.id} className="card-hover animate-slide-up cursor-default" style={{ animationDelay: `${i * 0.07}s` }}>
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-primary-50 flex flex-col items-center justify-center border border-primary-100">
                      <span className="text-xs text-primary-500 font-medium leading-none">{days[d.getDay()]}</span>
                      <span className="text-lg font-bold text-primary-700 leading-none">{d.getDate()}</span>
                    </div>
                    <div>
                      <p className="font-semibold text-gray-800">{d.toLocaleDateString('en-LK', { month: 'long', year: 'numeric' })}</p>
                      <p className="text-xs text-gray-500 mt-0.5">{s.availableDate}</p>
                    </div>
                  </div>
                  <span className="badge badge-success">Active</span>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Clock size={14} className="text-gray-400" />
                    {s.startTime} – {s.endTime}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Users size={14} className="text-gray-400" />
                    Max {s.maxAppointments} patients
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Modal open={showModal} onClose={() => setShowModal(false)} title="Add new schedule">
        <form onSubmit={handleSave} className="space-y-4">
          <FormField label="Available date">
            <input className="input-field" type="date" value={form.availableDate}
              min={new Date().toISOString().split('T')[0]}
              onChange={e => setForm(p => ({ ...p, availableDate: e.target.value }))} required />
          </FormField>
          <div className="grid grid-cols-2 gap-3">
            <FormField label="Start time">
              <input className="input-field" type="time" value={form.startTime}
                onChange={e => setForm(p => ({ ...p, startTime: e.target.value }))} required />
            </FormField>
            <FormField label="End time">
              <input className="input-field" type="time" value={form.endTime}
                onChange={e => setForm(p => ({ ...p, endTime: e.target.value }))} required />
            </FormField>
          </div>
          <FormField label="Max appointments">
            <input className="input-field" type="number" min="1" max="100" placeholder="e.g. 20"
              value={form.maxAppointments}
              onChange={e => setForm(p => ({ ...p, maxAppointments: e.target.value }))} required />
          </FormField>
          <div className="flex gap-3 pt-2">
            <button type="submit" className="btn-primary flex-1 justify-center" disabled={saving}>
              {saving ? <Spinner size={15} /> : 'Save schedule'}
            </button>
            <button type="button" onClick={() => setShowModal(false)} className="btn-secondary">Cancel</button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
