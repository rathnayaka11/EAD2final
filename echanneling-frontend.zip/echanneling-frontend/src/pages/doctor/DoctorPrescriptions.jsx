import React, { useEffect, useState } from 'react';
import { FileText } from 'lucide-react';
import api from '../../services/api';
import { prescriptionAPI } from '../../services/api';
import { PageHeader, FormField, Spinner } from '../../components/UI';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';

export default function DoctorPrescriptions() {
  const { user } = useAuth();
  const { addToast } = useToast();
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ appointmentId: '', diagnosis: '', medications: '', notes: '' });

  useEffect(() => {
    api.get(`/doctor/${user.id}/appointments`)
      .then(r => setAppointments(r.data))
      .catch(() => setAppointments([]))
      .finally(() => setLoading(false));
  }, [user]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.appointmentId) { addToast('Please select an appointment.', 'warning'); return; }
    setSaving(true);
    try {
      const appt = appointments.find(a => a.id === parseInt(form.appointmentId));
      await prescriptionAPI.issue({
        appointment: { id: parseInt(form.appointmentId) },
        diagnosis: form.diagnosis,
        medications: form.medications,
        notes: form.notes,
      });
      addToast('Prescription issued successfully!');
      setForm({ appointmentId: '', diagnosis: '', medications: '', notes: '' });
    } catch {
      addToast('Failed to issue prescription.', 'error');
    }
    setSaving(false);
  };

  return (
    <div>
      <PageHeader title="Issue prescription" subtitle="Write prescriptions for your patients" />
      <div className="max-w-2xl">
        <div className="card animate-slide-up">
          <div className="flex items-center gap-2 mb-5">
            <div className="w-9 h-9 rounded-xl bg-primary-50 flex items-center justify-center">
              <FileText size={18} className="text-primary-600" />
            </div>
            <h2 className="font-semibold text-gray-800">New prescription</h2>
          </div>

          {loading ? (
            <div className="flex justify-center py-8"><Spinner className="text-primary-500" /></div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <FormField label="Select appointment">
                <select className="input-field" value={form.appointmentId}
                  onChange={e => setForm(p => ({ ...p, appointmentId: e.target.value }))} required>
                  <option value="">Choose a patient appointment…</option>
                  {appointments.map(a => (
                    <option key={a.id} value={a.id}>
                      {a.patient?.fullName} — {a.schedule?.availableDate} ({a.type})
                    </option>
                  ))}
                </select>
              </FormField>
              <FormField label="Diagnosis">
                <textarea className="input-field" rows={3}
                  placeholder="e.g. Hypertension Stage 1, Acute pharyngitis…"
                  value={form.diagnosis} onChange={e => setForm(p => ({ ...p, diagnosis: e.target.value }))} required />
              </FormField>
              <FormField label="Medications">
                <textarea className="input-field" rows={4}
                  placeholder="e.g. Amoxicillin 500mg × 7 days, Paracetamol 500mg PRN…"
                  value={form.medications} onChange={e => setForm(p => ({ ...p, medications: e.target.value }))} required />
              </FormField>
              <FormField label="Instructions / Notes">
                <textarea className="input-field" rows={3}
                  placeholder="Rest, plenty of fluids, follow up in 1 week…"
                  value={form.notes} onChange={e => setForm(p => ({ ...p, notes: e.target.value }))} />
              </FormField>
              <button type="submit" className="btn-primary" disabled={saving}>
                {saving ? <Spinner size={15} /> : <FileText size={15} />}
                Issue prescription
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
