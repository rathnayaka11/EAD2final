import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Activity, Eye, EyeOff, Stethoscope, UserRound, ArrowRight, Loader2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { authAPI } from '../services/api';
import { FormField } from '../components/UI';

const ROLE_ROUTES = { ADMIN: '/dashboard', DOCTOR: '/doctor/schedules', PATIENT: '/patient/book' };

export default function LoginPage() {
  const [tab, setTab] = useState('login');
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [regRole, setRegRole] = useState('PATIENT');
  const { login } = useAuth();
  const { addToast } = useToast();
  const navigate = useNavigate();

  const [loginForm, setLoginForm] = useState({ email: '', password: '' });
  const [regForm, setRegForm] = useState({
    fullName: '', email: '', password: '', gender: '',
    specialty: '', hospitalAffiliations: '', consultationFee: '',
  });

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await authAPI.login({ email: loginForm.email, password: loginForm.password });
      const { token, role, fullName, status } = res.data;
      if (status === 'PENDING') {
        addToast('Your account is pending approval.', 'warning');
        setLoading(false);
        return;
      }
      login({ fullName, role, email: loginForm.email, status }, token);
      addToast(`Welcome back, ${fullName}!`);
      navigate(ROLE_ROUTES[role] || '/dashboard');
    } catch (err) {
      addToast(err.response?.data || 'Login failed. Check credentials.', 'error');
    }
    setLoading(false);
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const payload = {
        fullName: regForm.fullName,
        email: regForm.email,
        password: regForm.password,
        gender: regForm.gender,
        role: regRole,
        ...(regRole === 'DOCTOR' && {
          specialty: regForm.specialty,
          hospitalAffiliations: regForm.hospitalAffiliations,
          consultationFee: parseFloat(regForm.consultationFee) || 0,
        }),
      };
      await authAPI.register(payload);
      addToast(
        regRole === 'DOCTOR'
          ? 'Registration submitted! Awaiting admin approval.'
          : 'Account created! You can now log in.',
      );
      setTab('login');
    } catch (err) {
      addToast(err.response?.data || 'Registration failed.', 'error');
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 via-white to-blue-50 flex">
      {/* Left panel */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-primary-600 to-primary-800 p-12 flex-col justify-between relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="absolute rounded-full border border-white"
              style={{ width: 200 + i * 80, height: 200 + i * 80, top: '50%', left: '50%',
                transform: 'translate(-50%,-50%)', animation: `spin ${8 + i * 2}s linear infinite ${i % 2 === 0 ? '' : 'reverse'}` }} />
          ))}
        </div>
        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-12">
            <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur flex items-center justify-center">
              <Activity size={20} className="text-white" />
            </div>
            <span className="text-white font-semibold text-lg">eChanneling</span>
          </div>
          <h1 className="text-4xl font-bold text-white leading-tight mb-4">
            Healthcare<br />at your fingertips
          </h1>
          <p className="text-primary-200 text-base leading-relaxed">
            Book doctor appointments, manage schedules, and access prescriptions — all in one secure platform.
          </p>
        </div>
        <div className="relative z-10 grid grid-cols-3 gap-4">
          {[['Doctors', '50+'], ['Patients', '2k+'], ['Hospitals', '12']].map(([label, val]) => (
            <div key={label} className="bg-white/10 backdrop-blur rounded-xl p-4">
              <p className="text-white text-xl font-bold">{val}</p>
              <p className="text-primary-200 text-xs mt-0.5">{label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Right panel */}
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-md animate-slide-up">
          {/* Logo mobile */}
          <div className="lg:hidden flex items-center gap-2 mb-8 justify-center">
            <div className="w-9 h-9 rounded-xl bg-primary-500 flex items-center justify-center">
              <Activity size={18} className="text-white" />
            </div>
            <span className="font-bold text-gray-800 text-lg">eChanneling</span>
          </div>

          <div className="card shadow-soft">
            {/* Tabs */}
            <div className="flex rounded-xl bg-gray-100 p-1 mb-6">
              {['login', 'register'].map(t => (
                <button key={t} onClick={() => setTab(t)}
                  className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all duration-200 capitalize ${tab === t ? 'bg-white text-gray-800 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}>
                  {t === 'login' ? 'Log in' : 'Register'}
                </button>
              ))}
            </div>

            {tab === 'login' ? (
              <form onSubmit={handleLogin} className="space-y-4">
                <FormField label="Email">
                  <input className="input-field" type="email" placeholder="you@example.com"
                    value={loginForm.email} onChange={e => setLoginForm(p => ({ ...p, email: e.target.value }))} required />
                </FormField>
                <FormField label="Password">
                  <div className="relative">
                    <input className="input-field pr-10" type={showPw ? 'text' : 'password'} placeholder="••••••••"
                      value={loginForm.password} onChange={e => setLoginForm(p => ({ ...p, password: e.target.value }))} required />
                    <button type="button" onClick={() => setShowPw(p => !p)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                      {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </FormField>
                <button type="submit" className="btn-primary w-full justify-center mt-2" disabled={loading}>
                  {loading ? <Loader2 size={16} className="animate-spin" /> : <><span>Log in</span><ArrowRight size={16} /></>}
                </button>
              </form>
            ) : (
              <form onSubmit={handleRegister} className="space-y-4">
                {/* Role picker */}
                <div>
                  <p className="text-sm font-medium text-gray-700 mb-2">I am a</p>
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      { role: 'PATIENT', icon: UserRound, label: 'Patient' },
                      { role: 'DOCTOR',  icon: Stethoscope, label: 'Doctor' },
                    ].map(({ role, icon: Icon, label }) => (
                      <button key={role} type="button" onClick={() => setRegRole(role)}
                        className={`flex items-center gap-2 p-3 rounded-xl border-2 text-sm font-medium transition-all duration-200 ${regRole === role ? 'border-primary-500 bg-primary-50 text-primary-700' : 'border-gray-200 text-gray-600 hover:border-gray-300'}`}>
                        <Icon size={18} /> {label}
                      </button>
                    ))}
                  </div>
                </div>
                <FormField label="Full name">
                  <input className="input-field" placeholder="Your full name"
                    value={regForm.fullName} onChange={e => setRegForm(p => ({ ...p, fullName: e.target.value }))} required />
                </FormField>
                <div className="grid grid-cols-2 gap-3">
                  <FormField label="Email">
                    <input className="input-field" type="email" placeholder="you@example.com"
                      value={regForm.email} onChange={e => setRegForm(p => ({ ...p, email: e.target.value }))} required />
                  </FormField>
                  <FormField label="Password">
                    <input className="input-field" type="password" placeholder="Min 6 chars"
                      value={regForm.password} onChange={e => setRegForm(p => ({ ...p, password: e.target.value }))} required />
                  </FormField>
                </div>
                <FormField label="Gender">
                  <select className="input-field" value={regForm.gender} onChange={e => setRegForm(p => ({ ...p, gender: e.target.value }))} required>
                    <option value="">Select gender</option>
                    <option>Male</option><option>Female</option><option>Prefer not to say</option>
                  </select>
                </FormField>
                {regRole === 'DOCTOR' && (
                  <div className="space-y-3 pt-2 border-t border-gray-100 animate-slide-up">
                    <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Professional details</p>
                    <FormField label="Specialty">
                      <input className="input-field" placeholder="e.g. Cardiology"
                        value={regForm.specialty} onChange={e => setRegForm(p => ({ ...p, specialty: e.target.value }))} />
                    </FormField>
                    <FormField label="Hospital affiliations">
                      <input className="input-field" placeholder="e.g. Colombo National Hospital"
                        value={regForm.hospitalAffiliations} onChange={e => setRegForm(p => ({ ...p, hospitalAffiliations: e.target.value }))} />
                    </FormField>
                    <FormField label="Consultation fee (LKR)">
                      <input className="input-field" type="number" placeholder="e.g. 2500"
                        value={regForm.consultationFee} onChange={e => setRegForm(p => ({ ...p, consultationFee: e.target.value }))} />
                    </FormField>
                  </div>
                )}
                <button type="submit" className="btn-primary w-full justify-center mt-2" disabled={loading}>
                  {loading ? <Loader2 size={16} className="animate-spin" /> : <><span>Create account</span><ArrowRight size={16} /></>}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
