import React, { useEffect, useState } from 'react';
import { RefreshCw, TrendingUp } from 'lucide-react';
import { paymentAPI } from '../../services/api';
import { Table, StatusBadge, PageHeader, Spinner } from '../../components/UI';
import { useToast } from '../../context/ToastContext';

export default function AdminPayments() {
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);
  const { addToast } = useToast();

  const fetchPayments = () => {
    setLoading(true);
    paymentAPI.getAll()
      .then(r => setPayments(r.data))
      .catch(() => addToast('Failed to load payments.', 'error'))
      .finally(() => setLoading(false));
  };

  useEffect(() => { fetchPayments(); }, []);

  const total = payments.filter(p => p.status === 'SUCCESS').reduce((s, p) => s + (p.amount || 0), 0);

  return (
    <div>
      <PageHeader
        title="Payment records"
        subtitle="All transactions across the platform"
        action={
          <button onClick={fetchPayments} className="btn-secondary text-sm">
            <RefreshCw size={15} className={loading ? 'animate-spin' : ''} /> Refresh
          </button>
        }
      />

      {/* Total */}
      <div className="card mb-6 animate-slide-up bg-gradient-to-br from-primary-500 to-primary-700 border-0">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center">
            <TrendingUp size={22} className="text-white" />
          </div>
          <div>
            <p className="text-primary-100 text-sm">Total revenue</p>
            <p className="text-white text-2xl font-bold">LKR {total.toLocaleString()}</p>
          </div>
        </div>
      </div>

      <div className="card animate-slide-up" style={{ animationDelay: '0.1s' }}>
        {loading ? (
          <div className="flex justify-center py-12"><Spinner size={24} className="text-primary-500" /></div>
        ) : (
          <Table headers={['ID', 'Patient ID', 'Doctor ID', 'Amount (LKR)', 'Method', 'Status', 'Date']} empty="No payment records">
            {payments.map(p => (
              <tr key={p.id} className="table-row">
                <td className="px-4 py-3 text-xs text-gray-400 font-mono">#{p.id}</td>
                <td className="px-4 py-3 text-sm">{p.patientId}</td>
                <td className="px-4 py-3 text-sm">{p.doctorId}</td>
                <td className="px-4 py-3 font-semibold text-gray-800">{(p.amount || 0).toLocaleString()}</td>
                <td className="px-4 py-3 text-sm">
                  <span className="badge badge-gray">{p.method}</span>
                </td>
                <td className="px-4 py-3"><StatusBadge status={p.status} /></td>
                <td className="px-4 py-3 text-xs text-gray-500">
                  {p.paymentDate ? new Date(p.paymentDate).toLocaleDateString('en-LK', { day: 'numeric', month: 'short', year: 'numeric' }) : '—'}
                </td>
              </tr>
            ))}
          </Table>
        )}
      </div>
    </div>
  );
}
