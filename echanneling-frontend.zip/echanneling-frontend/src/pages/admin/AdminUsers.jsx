import React, { useEffect, useState } from 'react';
import { CheckCircle, RefreshCw } from 'lucide-react';
import { adminAPI } from '../../services/api';
import { Table, StatusBadge, PageHeader, Spinner } from '../../components/UI';
import { useToast } from '../../context/ToastContext';

export default function AdminUsers() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [approvingId, setApprovingId] = useState(null);
  const { addToast } = useToast();

  const fetchUsers = () => {
    setLoading(true);
    adminAPI.getAllUsers()
      .then(r => setUsers(r.data))
      .catch(() => addToast('Failed to load users.', 'error'))
      .finally(() => setLoading(false));
  };

  useEffect(() => { fetchUsers(); }, []);

  const approve = async (id, name) => {
    setApprovingId(id);
    try {
      await adminAPI.approveDoctor(id);
      addToast(`${name} approved successfully!`);
      fetchUsers();
    } catch {
      addToast('Approval failed.', 'error');
    }
    setApprovingId(null);
  };

  const doctors  = users.filter(u => u.role === 'DOCTOR');
  const patients = users.filter(u => u.role === 'PATIENT');

  return (
    <div>
      <PageHeader
        title="User management"
        subtitle="View and manage doctors and patients"
        action={
          <button onClick={fetchUsers} className="btn-secondary text-sm">
            <RefreshCw size={15} className={loading ? 'animate-spin' : ''} /> Refresh
          </button>
        }
      />

      {/* Doctors */}
      <div className="card mb-6 animate-slide-up">
        <div className="flex items-center gap-2 mb-4">
          <span className="w-2 h-5 rounded bg-primary-500" />
          <h2 className="font-semibold text-gray-800">Doctors</h2>
          <span className="text-xs text-gray-500 ml-1">({doctors.length})</span>
        </div>
        {loading ? (
          <div className="flex justify-center py-8"><Spinner className="text-primary-500" /></div>
        ) : (
          <Table headers={['Name', 'Email', 'Specialty', 'Hospital', 'Fee (LKR)', 'Status', 'Action']}>
            {doctors.map(u => (
              <tr key={u.id} className="table-row animate-fade-in">
                <td className="px-4 py-3 font-medium text-gray-800 text-sm">{u.fullName}</td>
                <td className="px-4 py-3 text-gray-500 text-xs">{u.email}</td>
                <td className="px-4 py-3 text-sm">{u.specialty || '—'}</td>
                <td className="px-4 py-3 text-sm text-gray-500">{u.hospitalAffiliations || '—'}</td>
                <td className="px-4 py-3 text-sm font-medium">{u.consultationFee ? `${u.consultationFee.toLocaleString()}` : '—'}</td>
                <td className="px-4 py-3"><StatusBadge status={u.accountStatus} /></td>
                <td className="px-4 py-3">
                  {u.accountStatus === 'PENDING' ? (
                    <button
                      onClick={() => approve(u.id, u.fullName)}
                      disabled={approvingId === u.id}
                      className="flex items-center gap-1.5 text-xs font-medium bg-primary-500 hover:bg-primary-600 text-white px-3 py-1.5 rounded-lg transition-all duration-200 active:scale-95 disabled:opacity-50"
                    >
                      {approvingId === u.id ? <Spinner size={12} /> : <CheckCircle size={12} />}
                      Approve
                    </button>
                  ) : (
                    <span className="text-xs text-gray-400">—</span>
                  )}
                </td>
              </tr>
            ))}
          </Table>
        )}
      </div>

      {/* Patients */}
      <div className="card animate-slide-up" style={{ animationDelay: '0.1s' }}>
        <div className="flex items-center gap-2 mb-4">
          <span className="w-2 h-5 rounded bg-blue-500" />
          <h2 className="font-semibold text-gray-800">Patients</h2>
          <span className="text-xs text-gray-500 ml-1">({patients.length})</span>
        </div>
        {loading ? (
          <div className="flex justify-center py-8"><Spinner className="text-primary-500" /></div>
        ) : (
          <Table headers={['Name', 'Email', 'Gender', 'Status']}>
            {patients.map(u => (
              <tr key={u.id} className="table-row animate-fade-in">
                <td className="px-4 py-3 font-medium text-gray-800 text-sm">{u.fullName}</td>
                <td className="px-4 py-3 text-gray-500 text-xs">{u.email}</td>
                <td className="px-4 py-3 text-sm">{u.gender || '—'}</td>
                <td className="px-4 py-3"><StatusBadge status={u.accountStatus} /></td>
              </tr>
            ))}
          </Table>
        )}
      </div>
    </div>
  );
}
