import React, { useEffect, useState } from 'react';
import { Users, Calendar, Stethoscope, TrendingUp, AlertTriangle } from 'lucide-react';
import { adminAPI } from '../services/api';
import { StatCard, LoadingPage, PageHeader } from '../components/UI';
import { useToast } from '../context/ToastContext';

export default function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const { addToast } = useToast();

  useEffect(() => {
    adminAPI.getDashboard()
      .then(r => setStats(r.data))
      .catch(() => addToast('Failed to load dashboard stats.', 'error'))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <LoadingPage />;

  return (
    <div>
      <PageHeader
        title="Admin Dashboard"
        subtitle="System overview and key metrics"
      />
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
        <StatCard icon={Users}       label="Total patients"     value={stats?.totalPatients || 0}     color="blue"   trend="Active users" />
        <StatCard icon={Stethoscope} label="Total doctors"      value={stats?.totalDoctors || 0}      color="primary" trend="Registered" />
        <StatCard icon={Calendar}    label="Total appointments" value={stats?.totalAppointments || 0} color="purple" trend="All time" />
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="card animate-slide-up">
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle size={18} className="text-amber-500" />
            <h2 className="font-semibold text-gray-800">Pending approvals</h2>
          </div>
          <p className="text-sm text-gray-500">Go to <strong>Users</strong> page to review and approve pending doctor registrations.</p>
        </div>
        <div className="card animate-slide-up" style={{ animationDelay: '0.1s' }}>
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp size={18} className="text-primary-500" />
            <h2 className="font-semibold text-gray-800">System health</h2>
          </div>
          <p className="text-sm text-gray-500">All services operational. Database connection active.</p>
          <div className="flex items-center gap-2 mt-3">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse-slow" />
            <span className="text-xs text-emerald-600 font-medium">API running on :8080</span>
          </div>
        </div>
      </div>
    </div>
  );
}
