import React, { useEffect, useState } from 'react';
import { RefreshCw } from 'lucide-react';
import api from '../../services/api';
import { Table, StatusBadge, PageHeader, Spinner } from '../../components/UI';
import { useToast } from '../../context/ToastContext';

export default function AdminAppointments() {
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const { addToast } = useToast();

  const fetch = () => {
    setLoading(true);
    // Using admin users list + appointment data from admin endpoint
    api.get('/admin/users')
      .then(() => api.get('/admin/dashboard'))
      .catch(() => {})
      .finally(() => setLoading(false));
    // Real endpoint - adjust if your backend exposes /admin/appointments
    api.get('/appointment/all').then(r => setAppointments(r.data)).catch(() => {
      // fallback: try alternative
      setAppointments([]);
      addToast('Appointments endpoint not found — check /appointment/all', 'warning');
      setLoading(false);
    });
  };

  useEffect(() => { fetch(); }, []);

  return (
    <div>
      <PageHeader
        title="All appointments"
        subtitle="System-wide appointment overview"
        action={
          <button onClick={fetch} className="btn-secondary text-sm">
            <RefreshCw size={15} className={loading ? 'animate-spin' : ''} /> Refresh
          </button>
        }
      />
      <div className="card animate-slide-up">
        {loading ? (
          <div className="flex justify-center py-12"><Spinner size={24} className="text-primary-500" /></div>
        ) : (
          <Table headers={['Patient', 'Doctor', 'Date', 'Time', 'Type', 'Status']} empty="No appointments found">
            {appointments.map(a => (
              <tr key={a.id} className="table-row">
                <td className="px-4 py-3 font-medium text-gray-800 text-sm">{a.patient?.fullName || '—'}</td>
                <td className="px-4 py-3 text-sm">{a.schedule?.doctor?.fullName || '—'}</td>
                <td className="px-4 py-3 text-sm text-gray-600">{a.schedule?.availableDate || '—'}</td>
                <td className="px-4 py-3 text-xs text-gray-500">{a.schedule?.startTime} – {a.schedule?.endTime}</td>
                <td className="px-4 py-3"><StatusBadge status={a.type} /></td>
                <td className="px-4 py-3"><StatusBadge status={a.status} /></td>
              </tr>
            ))}
          </Table>
        )}
      </div>
    </div>
  );
}
