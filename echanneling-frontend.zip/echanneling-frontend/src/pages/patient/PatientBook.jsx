import React, { useEffect, useState } from 'react';
import { Stethoscope, Calendar, CreditCard, Check, ChevronRight, ArrowLeft } from 'lucide-react';
import { adminAPI, appointmentAPI, paymentAPI } from '../../services/api';
import { StatusBadge, EmptyState, Spinner, FormField } from '../../components/UI';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { useNavigate } from 'react-router-dom';
import { doctorAPI } from '../../services/api';

const STEPS = [
  { label: 'Choose doctor',   icon: Stethoscope },
  { label: 'Select slot',     icon: Calendar    },
  { label: 'Confirm & pay',   icon: CreditCard  },
];

export default function PatientBook() {
  const { user } = useAuth();
  const { addToast } = useToast();
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [doctors, setDoctors] = useState([]);
  const [schedules, setSchedules] = useState([]);
  const [loadingDoctors, setLoadingDoctors] = useState(true);
  const [loadingSchedules, setLoadingSchedules] = useState(false);
  const [booking, setBooking] = useState(false);
  const [selectedDoctor, setSelectedDoctor] = useState(null);
  const [selectedSchedule, setSelectedSchedule] = useState(null);
  const [apptType, setApptType] = useState('PHYSICAL');
  const [payMethod, setPayMethod] = useState('VISA');

  useEffect(() => {
    adminAPI.getAllUsers()
      .then(r => setDoctors(r.data.filter(u => u.role === 'DOCTOR' && u.accountStatus === 'ACTIVE')))
      .catch(() => addToast('Failed to load doctors.', 'error'))
      .finally(() => setLoadingDoctors(false));
  }, []);

  const selectDoctor = (doc) => {
    setSelectedDoctor(doc);
    setLoadingSchedules(true);
    doctorAPI.getSchedules(doc.id)
      .then(r => { setSchedules(r.data); setStep(1); })
      .catch(() => addToast('Failed to load schedules.', 'error'))
      .finally(() => setLoadingSchedules(false));
  };

  const selectSchedule = (sch) => {
    setSelectedSchedule(sch);
    setStep(2);
  };

  const confirmBooking = async () => {
    setBooking(true);
    try {
      const apptRes = await appointmentAPI.book(user.id, selectedSchedule.id, apptType);
      const appt = apptRes.data;
      await paymentAPI.create({
        appointmentId: appt.id,
        patientId: user.id,
        doctorId: selectedDoctor.id,
        amount: selectedDoctor.consultationFee || 0,
        method: payMethod,
      });
      addToast(`Appointment confirmed with ${selectedDoctor.fullName}!`);
      navigate('/patient/appointments');
    } catch (err) {
      addToast(err.response?.data || 'Booking failed. Please try again.', 'error');
    }
    setBooking(false);
  };

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-xl font-semibold text-gray-800 mb-4">Book appointment</h1>
        {/* Step indicator */}
        <div className="flex items-center gap-2">
          {STEPS.map((s, i) => {
            const Icon = s.icon;
            const done = i < step;
            const active = i === step;
            return (
              <React.Fragment key={i}>
                <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium transition-all duration-300 ${active ? 'bg-primary-500 text-white shadow-glow' : done ? 'bg-primary-100 text-primary-700' : 'bg-gray-100 text-gray-400'}`}>
                  {done ? <Check size={12} /> : <Icon size={12} />}
                  <span className="hidden sm:inline">{s.label}</span>
                </div>
                {i < STEPS.length - 1 && <ChevronRight size={14} className="text-gray-300 shrink-0" />}
              </React.Fragment>
            );
          })}
        </div>
      </div>

      {/* Step 0: Choose doctor */}
      {step === 0 && (
        <div className="animate-slide-up">
          <p className="text-sm text-gray-500 mb-4">Select a doctor to view their available slots</p>
          {loadingDoctors ? (
            <div className="flex justify-center py-12"><Spinner size={24} className="text-primary-500" /></div>
          ) : doctors.length === 0 ? (
            <div className="card"><EmptyState icon={Stethoscope} title="No doctors available" description="No active doctors at the moment." /></div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {doctors.map((d, i) => (
                <button key={d.id} onClick={() => selectDoctor(d)}
                  className="card-hover text-left p-5 animate-slide-up cursor-pointer group"
                  style={{ animationDelay: `${i * 0.06}s` }}>
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-xl bg-primary-100 flex items-center justify-center text-primary-700 font-bold text-lg shrink-0 group-hover:bg-primary-500 group-hover:text-white transition-colors duration-200">
                      {d.fullName.charAt(0)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-gray-800">{d.fullName}</p>
                      <p className="text-sm text-primary-600 font-medium mt-0.5">{d.specialty || 'General Practice'}</p>
                      <p className="text-xs text-gray-500 mt-1 truncate">{d.hospitalAffiliations || 'Independent'}</p>
                      <p className="text-sm font-semibold text-gray-700 mt-2">
                        LKR {(d.consultationFee || 0).toLocaleString()}
                        <span className="text-xs font-normal text-gray-400"> / consultation</span>
                      </p>
                    </div>
                    <ChevronRight size={16} className="text-gray-300 group-hover:text-primary-500 transition-colors shrink-0 mt-1" />
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Step 1: Select schedule */}
      {step === 1 && (
        <div className="animate-slide-up">
          <button onClick={() => setStep(0)} className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-gray-700 mb-4 transition-colors">
            <ArrowLeft size={14} /> Back to doctors
          </button>
          <div className="flex items-center gap-3 mb-4 p-3 bg-primary-50 rounded-xl border border-primary-100">
            <div className="w-9 h-9 rounded-lg bg-primary-100 flex items-center justify-center text-primary-700 font-bold">
              {selectedDoctor?.fullName.charAt(0)}
            </div>
            <div>
              <p className="font-medium text-gray-800 text-sm">{selectedDoctor?.fullName}</p>
              <p className="text-xs text-primary-600">{selectedDoctor?.specialty}</p>
            </div>
          </div>
          <p className="text-sm text-gray-500 mb-4">Choose an available session</p>
          {loadingSchedules ? (
            <div className="flex justify-center py-12"><Spinner size={24} className="text-primary-500" /></div>
          ) : schedules.length === 0 ? (
            <div className="card"><EmptyState icon={Calendar} title="No schedules available" description="This doctor has no upcoming sessions." /></div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {schedules.map((s, i) => {
                const d = new Date(s.availableDate + 'T00:00:00');
                return (
                  <button key={s.id} onClick={() => selectSchedule(s)}
                    className="card-hover p-4 text-left cursor-pointer group animate-slide-up"
                    style={{ animationDelay: `${i * 0.06}s` }}>
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-xl bg-blue-50 flex flex-col items-center justify-center border border-blue-100 group-hover:bg-primary-500 group-hover:border-primary-500 transition-colors duration-200">
                        <span className="text-[10px] font-semibold text-blue-500 group-hover:text-primary-100 leading-none">
                          {d.toLocaleDateString('en', { month: 'short' })}
                        </span>
                        <span className="text-lg font-bold text-blue-700 group-hover:text-white leading-none">
                          {d.getDate()}
                        </span>
                      </div>
                      <div>
                        <p className="font-medium text-gray-800 text-sm">{d.toLocaleDateString('en', { weekday: 'long' })}</p>
                        <p className="text-xs text-gray-500">{s.startTime} – {s.endTime}</p>
                        <p className="text-xs text-gray-400 mt-0.5">Up to {s.maxAppointments} patients</p>
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Step 2: Confirm */}
      {step === 2 && (
        <div className="animate-slide-up max-w-lg">
          <button onClick={() => setStep(1)} className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-gray-700 mb-4 transition-colors">
            <ArrowLeft size={14} /> Back to schedules
          </button>
          <div className="card mb-4">
            <h3 className="font-semibold text-gray-800 mb-4 flex items-center gap-2">
              <Check size={16} className="text-primary-500" /> Appointment summary
            </h3>
            <div className="space-y-3 text-sm">
              {[
                ['Doctor',    selectedDoctor?.fullName],
                ['Specialty', selectedDoctor?.specialty || 'General Practice'],
                ['Date',      selectedSchedule?.availableDate],
                ['Time',      `${selectedSchedule?.startTime} – ${selectedSchedule?.endTime}`],
                ['Fee',       `LKR ${(selectedDoctor?.consultationFee || 0).toLocaleString()}`],
              ].map(([label, value]) => (
                <div key={label} className="flex justify-between">
                  <span className="text-gray-500">{label}</span>
                  <span className={`font-medium text-gray-800 ${label === 'Fee' ? 'text-primary-600' : ''}`}>{value}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="card space-y-4">
            <FormField label="Appointment type">
              <div className="grid grid-cols-2 gap-3">
                {['PHYSICAL', 'ONLINE'].map(t => (
                  <button key={t} type="button" onClick={() => setApptType(t)}
                    className={`p-3 rounded-xl border-2 text-sm font-medium transition-all duration-200 ${apptType === t ? 'border-primary-500 bg-primary-50 text-primary-700' : 'border-gray-200 text-gray-600 hover:border-gray-300'}`}>
                    {t === 'PHYSICAL' ? '🏥 Physical visit' : '💻 Online'}
                  </button>
                ))}
              </div>
            </FormField>
            <FormField label="Payment method">
              <div className="grid grid-cols-3 gap-2">
                {['VISA', 'MASTERCARD', 'FRIMI'].map(m => (
                  <button key={m} type="button" onClick={() => setPayMethod(m)}
                    className={`p-2.5 rounded-xl border-2 text-xs font-semibold transition-all duration-200 ${payMethod === m ? 'border-primary-500 bg-primary-50 text-primary-700' : 'border-gray-200 text-gray-500 hover:border-gray-300'}`}>
                    {m}
                  </button>
                ))}
              </div>
            </FormField>
            <button onClick={confirmBooking} className="btn-primary w-full justify-center" disabled={booking}>
              {booking ? <Spinner size={15} /> : <Check size={15} />}
              Confirm & pay LKR {(selectedDoctor?.consultationFee || 0).toLocaleString()}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
