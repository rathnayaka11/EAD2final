import React, { useEffect, useState } from 'react';
import { ClipboardList, FileText } from 'lucide-react';
import api from '../../services/api';
import { prescriptionAPI } from '../../services/api';
import { Table, StatusBadge, PageHeader, EmptyState, Spinner } from '../../components/UI';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';

export function PatientAppointments() {
  const { user } = useAuth();
  const { addToast } = useToast();
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Adjust to your actual endpoint for patient appointments
    api.get(`/appointment/patient/${user.id}`)
      .then(r => setAppointments(r.data))
      .catch(() => {
        addToast('Ensure /appointment/patient/{id} endpoint exists on backend.', 'warning');
        setAppointments([]);
      })
      .finally(() => setLoading(false));
  }, [user]);

  return (
    <div>
      <PageHeader title="My appointments" subtitle="Your booking history" />
      <div className="card animate-slide-up">
        {loading ? (
          <div className="flex justify-center py-12"><Spinner size={24} className="text-primary-500" /></div>
        ) : appointments.length === 0 ? (
          <EmptyState icon={ClipboardList} title="No appointments yet" description="Book your first appointment to see it here." />
        ) : (
          <Table headers={['Doctor', 'Specialty', 'Date', 'Time', 'Type', 'Status']}>
            {appointments.map(a => (
              <tr key={a.id} className="table-row animate-fade-in">
                <td className="px-4 py-3 font-medium text-gray-800 text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-full bg-primary-100 flex items-center justify-center text-primary-700 text-xs font-semibold shrink-0">
                      {a.schedule?.doctor?.fullName?.charAt(0)}
                    </div>
                    {a.schedule?.doctor?.fullName}
                  </div>
                </td>
                <td className="px-4 py-3 text-sm text-gray-500">{a.schedule?.doctor?.specialty || '—'}</td>
                <td className="px-4 py-3 text-sm text-gray-600">{a.schedule?.availableDate}</td>
                <td className="px-4 py-3 text-xs text-gray-500">{a.schedule?.startTime}</td>
                <td className="px-4 py-3"><StatusBadge status={a.type} /></td>
                <td className="px-4 py-3"><StatusBadge status={a.status} /></td>
              </tr>
            ))}
          </Table>
        )}
      </div>
    </div>
  );
}

export function PatientPrescriptions() {
  const { user } = useAuth();
  const { addToast } = useToast();
  const [appointments, setAppointments] = useState([]);
  const [prescriptions, setPrescriptions] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get(`/appointment/patient/${user.id}`)
      .then(async r => {
        const appts = r.data;
        setAppointments(appts);
        const rxMap = {};
        await Promise.all(appts.map(async a => {
          try {
            const rx = await prescriptionAPI.getByAppointment(a.id);
            rxMap[a.id] = rx.data;
          } catch {}
        }));
        setPrescriptions(rxMap);
      })
      .catch(() => setAppointments([]))
      .finally(() => setLoading(false));
  }, [user]);

  const rxList = Object.values(prescriptions);

  return (
    <div>
      <PageHeader title="My prescriptions" subtitle="Issued by your doctors" />
      {loading ? (
        <div className="flex justify-center py-12"><Spinner size={24} className="text-primary-500" /></div>
      ) : rxList.length === 0 ? (
        <div className="card animate-slide-up">
          <EmptyState icon={FileText} title="No prescriptions yet" description="Prescriptions will appear here after your appointments." />
        </div>
      ) : (
        <div className="space-y-4">
          {rxList.map((rx, i) => (
            <div key={rx.id} className="card animate-slide-up" style={{ animationDelay: `${i * 0.08}s` }}>
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-primary-50 flex items-center justify-center">
                    <FileText size={18} className="text-primary-500" />
                  </div>
                  <div>
                    <p className="font-semibold text-gray-800">Prescription #{rx.id}</p>
                    <p className="text-xs text-gray-500 mt-0.5">
                      {rx.appointment?.schedule?.doctor?.fullName} · {rx.appointment?.schedule?.availableDate}
                    </p>
                  </div>
                </div>
                <span className="badge badge-success">Issued</span>
              </div>
              <div className="space-y-3 border-t border-gray-50 pt-4">
                {[
                  ['Diagnosis', rx.diagnosis],
                  ['Medications', rx.medications],
                  ['Instructions', rx.notes],
                ].map(([label, val]) => val ? (
                  <div key={label}>
                    <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-1">{label}</p>
                    <p className="text-sm text-gray-700 leading-relaxed">{val}</p>
                  </div>
                ) : null)}
              </div>
              {rx.issuedDate && (
                <p className="text-xs text-gray-400 mt-4 pt-3 border-t border-gray-50">
                  Issued on {new Date(rx.issuedDate).toLocaleDateString('en-LK', { day: 'numeric', month: 'long', year: 'numeric' })}
                </p>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
