import React from 'react';
import { Loader2 } from 'lucide-react';

// Spinner
export function Spinner({ size = 20, className = '' }) {
  return <Loader2 size={size} className={`animate-spin ${className}`} />;
}

// Loading page
export function LoadingPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary-50 to-white">
      <div className="flex flex-col items-center gap-4 animate-fade-in">
        <div className="w-14 h-14 rounded-2xl bg-primary-500 flex items-center justify-center shadow-glow animate-pulse-slow">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M22 12h-4l-3 9L9 3l-3 9H2"/>
          </svg>
        </div>
        <p className="text-gray-500 text-sm font-medium animate-pulse">Loading…</p>
      </div>
    </div>
  );
}

// Empty state
export function EmptyState({ icon: Icon, title, description }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center animate-fade-in">
      <div className="w-16 h-16 rounded-2xl bg-gray-100 flex items-center justify-center mb-4">
        <Icon size={28} className="text-gray-400" />
      </div>
      <p className="font-medium text-gray-700 mb-1">{title}</p>
      {description && <p className="text-sm text-gray-500">{description}</p>}
    </div>
  );
}

// Status badge
export function StatusBadge({ status }) {
  const map = {
    ACTIVE:    'badge-success',
    PENDING:   'badge-warning',
    CONFIRMED: 'badge-success',
    CANCELLED: 'badge-danger',
    SUCCESS:   'badge-success',
    FAILED:    'badge-danger',
    PHYSICAL:  'badge-info',
    ONLINE:    'badge-purple',
    DOCTOR:    'badge-purple',
    PATIENT:   'badge-info',
    ADMIN:     'badge-gray',
  };
  return <span className={map[status] || 'badge-gray'}>{status}</span>;
}

// Stats card with animated counter
export function StatCard({ icon: Icon, label, value, color = 'primary', trend }) {
  const colorMap = {
    primary: { bg: 'bg-primary-50', icon: 'text-primary-600', ring: 'ring-primary-100' },
    blue:    { bg: 'bg-blue-50',    icon: 'text-blue-600',    ring: 'ring-blue-100' },
    amber:   { bg: 'bg-amber-50',   icon: 'text-amber-600',   ring: 'ring-amber-100' },
    purple:  { bg: 'bg-purple-50',  icon: 'text-purple-600',  ring: 'ring-purple-100' },
  };
  const c = colorMap[color] || colorMap.primary;
  return (
    <div className="stat-card animate-slide-up">
      <div className={`w-12 h-12 rounded-xl ${c.bg} ring-4 ${c.ring} flex items-center justify-center shrink-0`}>
        <Icon size={22} className={c.icon} />
      </div>
      <div>
        <p className="text-2xl font-semibold text-gray-800">{value}</p>
        <p className="text-sm text-gray-500 mt-0.5">{label}</p>
        {trend && <p className="text-xs text-emerald-600 mt-1 font-medium">{trend}</p>}
      </div>
    </div>
  );
}

// Page header
export function PageHeader({ title, subtitle, action }) {
  return (
    <div className="flex items-start justify-between mb-6 animate-fade-in">
      <div>
        <h1 className="text-xl font-semibold text-gray-800">{title}</h1>
        {subtitle && <p className="text-sm text-gray-500 mt-0.5">{subtitle}</p>}
      </div>
      {action && <div>{action}</div>}
    </div>
  );
}

// Table wrapper
export function Table({ headers, children, empty }) {
  return (
    <div className="overflow-x-auto rounded-xl border border-gray-100">
      <table className="w-full text-sm">
        <thead>
          <tr className="bg-gray-50 border-b border-gray-100">
            {headers.map(h => (
              <th key={h} className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide whitespace-nowrap">{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {children || (
            <tr><td colSpan={headers.length} className="py-12 text-center text-gray-400 text-sm">{empty || 'No data'}</td></tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

// Modal
export function Modal({ open, onClose, title, children, maxWidth = 'max-w-lg' }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/30 backdrop-blur-sm" onClick={onClose} />
      <div className={`relative w-full ${maxWidth} bg-white rounded-2xl shadow-2xl animate-scale-in`}>
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
          <h2 className="font-semibold text-gray-800">{title}</h2>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-gray-100 transition-colors">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M18 6L6 18M6 6l12 12"/></svg>
          </button>
        </div>
        <div className="p-6">{children}</div>
      </div>
    </div>
  );
}

// Form field wrapper
export function FormField({ label, error, children }) {
  return (
    <div className="flex flex-col gap-1.5">
      {label && <label className="text-sm font-medium text-gray-700">{label}</label>}
      {children}
      {error && <p className="text-xs text-red-500">{error}</p>}
    </div>
  );
}
