import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  LayoutDashboard, Users, Calendar, CreditCard, CalendarPlus,
  ClipboardList, FileText, Coins, Stethoscope, LogOut, Menu, X,
  Activity, ChevronRight
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const navConfig = {
  ADMIN: [
    { path: '/dashboard',          icon: LayoutDashboard, label: 'Dashboard' },
    { path: '/admin/users',        icon: Users,           label: 'Users' },
    { path: '/admin/appointments', icon: Calendar,        label: 'Appointments' },
    { path: '/admin/payments',     icon: CreditCard,      label: 'Payments' },
  ],
  DOCTOR: [
    { path: '/doctor/schedules',     icon: CalendarPlus,  label: 'My Schedules' },
    { path: '/doctor/appointments',  icon: ClipboardList, label: 'Appointments' },
    { path: '/doctor/prescriptions', icon: FileText,      label: 'Prescriptions' },
    { path: '/doctor/earnings',      icon: Coins,         label: 'Earnings' },
  ],
  PATIENT: [
    { path: '/patient/book',            icon: CalendarPlus,  label: 'Book Appointment' },
    { path: '/patient/appointments',    icon: ClipboardList, label: 'My Appointments' },
    { path: '/patient/prescriptions',   icon: FileText,      label: 'Prescriptions' },
  ],
};

const roleColors = {
  ADMIN:   'bg-purple-100 text-purple-700',
  DOCTOR:  'bg-emerald-100 text-emerald-700',
  PATIENT: 'bg-blue-100 text-blue-700',
};

export default function Layout({ children }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  const links = navConfig[user?.role] || [];

  const handleLogout = () => { logout(); navigate('/login'); };

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      {/* Brand */}
      <div className="px-5 py-5 border-b border-gray-100">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-primary-500 flex items-center justify-center shadow-glow">
            <Activity size={18} className="text-white" />
          </div>
          <div>
            <p className="font-semibold text-gray-800 text-sm leading-tight">eChanneling</p>
            <p className="text-xs text-gray-400">Medical Portal</p>
          </div>
        </div>
      </div>

      {/* User info */}
      <div className="px-4 py-4 border-b border-gray-100">
        <div className="bg-gray-50 rounded-xl p-3">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-primary-500 flex items-center justify-center text-white font-semibold text-sm shrink-0">
              {user?.fullName?.charAt(0) || '?'}
            </div>
            <div className="min-w-0">
              <p className="text-sm font-medium text-gray-800 truncate">{user?.fullName}</p>
              <p className="text-xs text-gray-500 truncate">{user?.email}</p>
            </div>
          </div>
          <div className="mt-2">
            <span className={`text-xs font-medium px-2.5 py-0.5 rounded-full ${roleColors[user?.role]}`}>{user?.role}</span>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        {links.map(({ path, icon: Icon, label }) => {
          const active = location.pathname === path;
          return (
            <button
              key={path}
              onClick={() => { navigate(path); setMobileOpen(false); }}
              className={`w-full sidebar-link ${active ? 'active' : ''}`}
            >
              <Icon size={18} className={active ? 'text-white' : 'text-gray-400 group-hover:text-primary-600'} />
              <span className="flex-1 text-left">{label}</span>
              {active && <ChevronRight size={14} className="text-white/70" />}
            </button>
          );
        })}
      </nav>

      {/* Logout */}
      <div className="px-3 py-4 border-t border-gray-100">
        <button onClick={handleLogout} className="w-full sidebar-link text-red-500 hover:bg-red-50 hover:text-red-600">
          <LogOut size={18} />
          <span>Log out</span>
        </button>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden">
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex w-64 bg-white border-r border-gray-100 flex-col shrink-0 shadow-sm">
        <SidebarContent />
      </aside>

      {/* Mobile sidebar overlay */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div className="absolute inset-0 bg-black/30 backdrop-blur-sm" onClick={() => setMobileOpen(false)} />
          <aside className="relative w-72 bg-white shadow-2xl animate-slide-in-right flex flex-col">
            <div className="absolute top-4 right-4">
              <button onClick={() => setMobileOpen(false)} className="p-2 rounded-lg hover:bg-gray-100">
                <X size={18} />
              </button>
            </div>
            <SidebarContent />
          </aside>
        </div>
      )}

      {/* Main area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top bar (mobile) */}
        <header className="lg:hidden bg-white border-b border-gray-100 px-4 py-3 flex items-center gap-3">
          <button onClick={() => setMobileOpen(true)} className="p-2 rounded-lg hover:bg-gray-100">
            <Menu size={20} />
          </button>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-primary-500 flex items-center justify-center">
              <Activity size={14} className="text-white" />
            </div>
            <span className="font-semibold text-gray-800 text-sm">eChanneling</span>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto p-6 lg:p-8">
          <div className="max-w-6xl mx-auto page-enter">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
