import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ToastProvider } from './context/ToastContext';
import Layout from './components/Layout';
import { LoadingPage } from './components/UI';

// Pages
import LoginPage from './pages/LoginPage';
import AdminDashboard from './pages/admin/AdminDashboard';
import AdminUsers from './pages/admin/AdminUsers';
import AdminAppointments from './pages/admin/AdminAppointments';
import AdminPayments from './pages/admin/AdminPayments';
import DoctorSchedules from './pages/doctor/DoctorSchedules';
import DoctorAppointments from './pages/doctor/DoctorAppointments';
import DoctorPrescriptions from './pages/doctor/DoctorPrescriptions';
import DoctorEarnings from './pages/doctor/DoctorEarnings';
import PatientBook from './pages/patient/PatientBook';
import { PatientAppointments, PatientPrescriptions } from './pages/patient/PatientPages';

const ROLE_HOME = { ADMIN: '/dashboard', DOCTOR: '/doctor/schedules', PATIENT: '/patient/book' };

function ProtectedRoute({ children, roles }) {
  const { user, loading } = useAuth();
  if (loading) return <LoadingPage />;
  if (!user) return <Navigate to="/login" replace />;
  if (roles && !roles.includes(user.role)) return <Navigate to={ROLE_HOME[user.role] || '/login'} replace />;
  return <Layout>{children}</Layout>;
}

function PublicRoute({ children }) {
  const { user, loading } = useAuth();
  if (loading) return <LoadingPage />;
  if (user) return <Navigate to={ROLE_HOME[user.role] || '/dashboard'} replace />;
  return children;
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <ToastProvider>
          <Routes>
            {/* Public */}
            <Route path="/login" element={<PublicRoute><LoginPage /></PublicRoute>} />
            <Route path="/" element={<Navigate to="/login" replace />} />

            {/* Admin */}
            <Route path="/dashboard"          element={<ProtectedRoute roles={['ADMIN']}><AdminDashboard /></ProtectedRoute>} />
            <Route path="/admin/users"         element={<ProtectedRoute roles={['ADMIN']}><AdminUsers /></ProtectedRoute>} />
            <Route path="/admin/appointments"  element={<ProtectedRoute roles={['ADMIN']}><AdminAppointments /></ProtectedRoute>} />
            <Route path="/admin/payments"      element={<ProtectedRoute roles={['ADMIN']}><AdminPayments /></ProtectedRoute>} />

            {/* Doctor */}
            <Route path="/doctor/schedules"     element={<ProtectedRoute roles={['DOCTOR']}><DoctorSchedules /></ProtectedRoute>} />
            <Route path="/doctor/appointments"  element={<ProtectedRoute roles={['DOCTOR']}><DoctorAppointments /></ProtectedRoute>} />
            <Route path="/doctor/prescriptions" element={<ProtectedRoute roles={['DOCTOR']}><DoctorPrescriptions /></ProtectedRoute>} />
            <Route path="/doctor/earnings"      element={<ProtectedRoute roles={['DOCTOR']}><DoctorEarnings /></ProtectedRoute>} />

            {/* Patient */}
            <Route path="/patient/book"            element={<ProtectedRoute roles={['PATIENT']}><PatientBook /></ProtectedRoute>} />
            <Route path="/patient/appointments"    element={<ProtectedRoute roles={['PATIENT']}><PatientAppointments /></ProtectedRoute>} />
            <Route path="/patient/prescriptions"   element={<ProtectedRoute roles={['PATIENT']}><PatientPrescriptions /></ProtectedRoute>} />

            {/* Fallback */}
            <Route path="*" element={<Navigate to="/login" replace />} />
          </Routes>
        </ToastProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
