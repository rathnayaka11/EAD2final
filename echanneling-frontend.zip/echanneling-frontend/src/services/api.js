import axios from 'axios';

const BASE_URL = 'http://localhost:8080/api';

const api = axios.create({
  baseURL: BASE_URL,
  headers: { 'Content-Type': 'application/json' },
});

// Attach JWT to every request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Auth
export const authAPI = {
  login:    (data) => api.post('/auth/login', data),
  register: (data) => api.post('/auth/register', data),
};

// Admin
export const adminAPI = {
  getDashboard:  ()   => api.get('/admin/dashboard'),
  getAllUsers:    ()   => api.get('/admin/users'),
  approveDoctor: (id) => api.put(`/admin/user/${id}/approve`),
};

// Doctor
export const doctorAPI = {
  createSchedule:  (doctorId, schedule) => api.post(`/doctor/${doctorId}/schedule`, schedule),
  getSchedules:    (doctorId)           => api.get(`/doctor/${doctorId}/schedules`),
};

// Appointment
export const appointmentAPI = {
  book: (patientId, scheduleId, type) =>
    api.post(`/appointment/book/${patientId}/${scheduleId}/${type}`),
};

// Payment
export const paymentAPI = {
  create:         (data)     => api.post('/payments/', data),
  getAll:         ()         => api.get('/payments/'),
  getDoctorEarnings: (docId) => api.get(`/payments/doctor/${docId}`),
};

// Prescription
export const prescriptionAPI = {
  issue:        (data)      => api.post('/prescriptions/', data),
  getByAppointment: (apptId) => api.get(`/prescriptions/appointment/${apptId}`),
};

export default api;
