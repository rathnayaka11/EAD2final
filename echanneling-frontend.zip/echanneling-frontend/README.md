# eChanneling Frontend

React + Tailwind CSS frontend for the eChanneling Spring Boot backend.

## Quick start

```bash
npm install
npm start
```

Opens at **http://localhost:3000**

## Backend connection

The API base URL is set in `src/services/api.js`:

```js
const BASE_URL = 'http://localhost:8080/api';
```

Make sure your Spring Boot backend is running on port 8080.

## Role-based routing

| Role    | Landing page           |
|---------|------------------------|
| ADMIN   | /dashboard             |
| DOCTOR  | /doctor/schedules      |
| PATIENT | /patient/book          |

## Backend endpoints used

| Feature                    | Endpoint                                        |
|----------------------------|-------------------------------------------------|
| Login                      | POST /api/auth/login                            |
| Register                   | POST /api/auth/register                         |
| Admin dashboard stats      | GET  /api/admin/dashboard                       |
| All users                  | GET  /api/admin/users                           |
| Approve doctor             | PUT  /api/admin/user/{id}/approve               |
| Create schedule            | POST /api/doctor/{doctorId}/schedule            |
| Get doctor schedules       | GET  /api/doctor/{doctorId}/schedules           |
| Book appointment           | POST /api/appointment/book/{patientId}/{scheduleId}/{type} |
| Create payment             | POST /api/payments/                             |
| All payments (admin)       | GET  /api/payments/                             |
| Doctor earnings            | GET  /api/payments/doctor/{doctorId}            |
| Issue prescription         | POST /api/prescriptions/                        |
| Get prescription           | GET  /api/prescriptions/appointment/{apptId}    |

### Additional endpoints to add on backend (recommended)

```java
// Patient's own appointments
GET /api/appointment/patient/{patientId}

// Doctor's appointments
GET /api/doctor/{doctorId}/appointments

// All appointments (admin)
GET /api/appointment/all
```

## Tech stack

- React 18
- React Router v6
- Tailwind CSS
- Axios
- Lucide React (icons)
